package com.example.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.dto.Activity;

public interface IActivityService{
void addActivity(Activity activity);
List<Activity> getAllActivities();
void updateActivity(int id,Activity activity);
List<Activity> getActivitiesByName(String name);
List<Activity> showExistingActivity(String username);


}
