package com.example.demo.repository;


import org.springframework.data.repository.CrudRepository;

import com.example.demo.dto.Activity;


public interface ActivityRepository extends CrudRepository<Activity,Integer>{
	//List<Activity> findByActivities(String activity_name);
	
	//public List<Activity> findByActivity_name();

}
