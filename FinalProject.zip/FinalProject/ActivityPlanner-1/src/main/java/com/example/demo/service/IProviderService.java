package com.example.demo.service;

import com.example.demo.dto.Admin;
import com.example.demo.dto.EndUser;
import com.example.demo.dto.Provider;

public interface IProviderService {
void addProvider(Provider provider);
public Provider authenticateProvider(Provider provider);

}
