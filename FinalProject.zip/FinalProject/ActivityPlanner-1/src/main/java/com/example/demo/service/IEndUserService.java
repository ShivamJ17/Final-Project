package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.EndUser;

public interface IEndUserService {
	public List<EndUser> getAllEndUsers();
	EndUser getEndUserById(int id);
	void addEndUser(EndUser enduser);
	public EndUser Authenticate(EndUser user);
}
