package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.Activity;
import com.example.demo.dto.Cart;

public interface ICartService {
	List<Cart> getAllCartItems();
	Cart getCartItemById(int id);
	void addToCart(Activity activity, int userid);
}
