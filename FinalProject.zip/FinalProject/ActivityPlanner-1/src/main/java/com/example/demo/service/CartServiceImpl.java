package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ICartDao;
import com.example.demo.dto.Activity;
import com.example.demo.dto.Cart;
@Service
public class CartServiceImpl implements ICartService {
	@Autowired
	private ICartDao daoref;

	@Override
	public List<Cart> getAllCartItems() {
		
		return daoref.findAll();
	}

	@Override
	public Cart getCartItemById(int id) {
		Integer i=id;
		Cart a= daoref.findById(i).get();
		System.out.println(a);
		return a;
	}
	//there will be a function to add items to cart when 
	//add to cart is clicked,data from the page will be copied into the cart table
	
	public void deleteCartItem(int id)
	{
		daoref.deleteById(id);
	}

	
	public void addToCart(Activity activity , int userid) {
		Cart cart=new Cart();
		cart.setActivity_name(activity.getActivity_name());
		cart.setactivity_details(activity.getactivity_details());
		cart.setProvider_id(activity.getProvider().getProvider_id());
		cart.setUser_id(userid);
		daoref.save(cart);

		
	}

}
