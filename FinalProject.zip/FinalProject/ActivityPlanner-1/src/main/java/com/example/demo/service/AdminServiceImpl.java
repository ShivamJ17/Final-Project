package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IAdminDao;
import com.example.demo.dto.Admin;

import com.example.demo.repository.AdminRepository;

@Service
public class AdminServiceImpl implements IAdminService {
	@Autowired
	private IAdminDao daoref;
	@Autowired
	private AdminRepository adminRepository;
	@Override
	public List<Admin> getAllAdmins() {
		return daoref.findAll();
	}

	@Override
	public Admin getAdminById(int id) {
		Integer i=id;
		Admin a=daoref.findById(i).get();
		System.out.println(a);
		return a;
	}

	public void addAdmin(Admin admin)
	{
		daoref.save(admin);
	}
	public void deleteAdmin(int id)
	{
		daoref.deleteById(id);
	}

	@Override
	public Admin authenticateAdmin(Admin admin) {
		Admin temp=new Admin();
		temp.setUsername(admin.getUsername());
		temp.setPassword(admin.getPassword());
		List<Admin> admins = adminRepository.findByUsername(admin.getUsername());
		if(admins.size()>0) {
			return admins.get(0);
		}
		return null;
	}
}
