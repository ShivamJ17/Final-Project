package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Admin;
import com.example.demo.dto.EndUser;
import com.example.demo.service.IAdminService;
@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class AdminController {
	@Autowired
	IAdminService ref;
	@RequestMapping("/welcome")
	public String Welcome()
	{
		return "Welcome to ActivityPlanner";
	}
	@RequestMapping("/admins/{id}")
	public Admin getAdminById(@PathVariable int id)
	{
		return ref.getAdminById(id);
	}
	@PostMapping("/authenticateadmin")
	public ResponseEntity<?> AuthenticateAdmin(@RequestBody Admin admin) {
		Admin temp = ref.authenticateAdmin(admin);
		if (temp != null) {
			return new ResponseEntity<Admin>(admin, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Authentication Failed", HttpStatus.OK);
	}
	

}
