package com.example.demo.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Provider;

@Repository
public interface IProviderDao extends CrudRepository<Provider, Integer>{

}
