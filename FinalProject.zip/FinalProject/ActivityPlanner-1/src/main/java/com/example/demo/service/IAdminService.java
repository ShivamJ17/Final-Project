package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.Admin;

public interface IAdminService {
	List<Admin> getAllAdmins();
	Admin getAdminById(int id);
	public Admin authenticateAdmin(Admin admin);

}
