package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IProviderDao;

import com.example.demo.dto.Provider;


import com.example.demo.repository.ProviderRepository;

@Service
public class ProviderServiceImpl implements IProviderService {
	@Autowired
	private IProviderDao daoref;
	@Autowired
	private ProviderRepository providerrepository ;
	
	@Override
	public void addProvider(Provider provider) {
			daoref.save(provider);
	}
	
	@Override
	public Provider authenticateProvider(Provider provider)
	{
	//	logger.info(provider.getUsername()+ " " +provider.getPassword());
		Provider temp=new Provider();
		temp.setUsername(provider.getUsername());
		temp.setPassword(provider.getPassword());
		List<Provider> providers = providerrepository.findByUsername(provider.getUsername());
		if(providers.size()>0) {
			System.out.println(providers.get(0));
			return providers.get(0);
		}
		return null;
}
}
