package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.EndUser;
import com.example.demo.service.IEndUserService;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
public class EndUserController {
	@Autowired
	IEndUserService ref;

	
  
	 
	  @RequestMapping("/endusers/{id}")
	  public EndUser getEndUserById(@PathVariable int id) 
	  {
		  return ref.getEndUserById(id);
	  }
	 
	  @RequestMapping(method = RequestMethod.POST, value="/register")
	  public void addEndUser(@RequestBody EndUser enduser)
	  {
		  ref.addEndUser(enduser); 
	  }
	
	//@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	@PostMapping("/authenticate")
	public ResponseEntity<?> AuthenticateUser(@RequestBody EndUser user) {
		EndUser temp = ref.Authenticate(user);
		if (temp != null) {
			return new ResponseEntity<EndUser>(user, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Authentication Failed", HttpStatus.OK);
	}

}
