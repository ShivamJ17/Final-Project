package com.example.demo.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cart {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int item_no;
private int provider_id;	
private String activity_name;
private String activity_details;
private int user_id;
public Cart(int item_no,int provider_id, String activity_name, String activity_details, int user_id) {
	super();
	this.item_no=item_no;
	this.provider_id = provider_id;
	this.activity_name = activity_name;
	this.activity_details = activity_details;
	this.user_id = user_id;
}
public Cart() {
	
}
public int getItem_no() {
	return item_no;
}

public int getProvider_id() {
	return provider_id;
}
public void setProvider_id(int provider_id) {
	this.provider_id = provider_id;
}
public String getActivity_name() {
	return activity_name;
}
public void setActivity_name(String activity_name) {
	this.activity_name = activity_name;
}
public String getactivity_details() {
	return activity_details;
}
public void setactivity_details(String activity_details) {
	this.activity_details = activity_details;
}
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}



}
