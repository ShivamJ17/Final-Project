package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Activity;

import com.example.demo.dto.Provider;
import com.example.demo.service.IActivityService;

@RestController
@CrossOrigin(allowedHeaders = "*", origins = "*")
@RequestMapping("/activity")
public class ActivityController {
	@Autowired
	private IActivityService activityservice;

	
	  @RequestMapping(method = RequestMethod.POST,value="/providers/{providerId}/activities") 
	  public void addActivity(@RequestBody Activity activity, @PathVariable Integer providerId)
	  { activity.setProvider(new Provider(providerId,"","","","",""));
	  activityservice.addActivity(activity); }
	  
	 

	@RequestMapping("/verifyactivity")
	public List<Activity> toBeVerified() {
		return activityservice.getAllActivities();
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/update/{id}")
	public void updateActivity(@PathVariable int id, @RequestBody Activity activity) { // activity.setStatus("true");
		activityservice.updateActivity(id, activity);
	}

	/*
	 * @RequestMapping("/activities/{name}") public List<Activity>
	 * getActivityByActivityNmae(@PathVariable String name) { return
	 * activityservice.getActivitiesByName(name);
	 * 
	 * }
	 */
	@RequestMapping("/activities/{name}")
	public List<Activity> getActivityByActivityName(@PathVariable("username") String name) {
		return activityservice.getActivitiesByName(name);
	}
//	@RequestMapping("/relatedactvities/{provider_id}")
//	public List<Activity> showExistingActivity(@PathVariable int provider_id)
//	{
//		return activityservice.showExistingActivity(provider_id);
//	}

	@RequestMapping(value = "/relatedactvities/{username}", method = RequestMethod.GET)
	public List<Activity> showExistingActivity(@PathVariable("username") String username) {
		System.out.println("hey");
		List<Activity> act = activityservice.showExistingActivity(username);
		System.out.println(act);
		return act;
	}

}
