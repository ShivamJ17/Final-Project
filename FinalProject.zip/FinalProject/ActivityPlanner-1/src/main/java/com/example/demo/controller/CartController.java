package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Activity;
import com.example.demo.dto.Cart;
import com.example.demo.service.ICartService;
@RestController
public class CartController {
	@Autowired
	ICartService ref;
	@RequestMapping("/cart/{id}")
	public Cart getCartItemById(@PathVariable int id)
	{
		return ref.getCartItemById(id);
	}

	@RequestMapping(method =RequestMethod.POST , value = "/cart/addItem/userid" )
	public void addActivityToCart(@RequestBody Activity activity , @PathVariable int userid)
	{
		ref.addToCart(activity, userid);
	
	}
}
