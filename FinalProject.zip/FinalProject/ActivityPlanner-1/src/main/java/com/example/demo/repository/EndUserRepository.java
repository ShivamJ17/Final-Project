package com.example.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.dto.EndUser;

public interface EndUserRepository extends CrudRepository<EndUser, Integer> {
	List<EndUser> findByUsername(String username);

}
