package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IActivityDao;
import com.example.demo.dto.Activity;

@Service
public class ActivityServiceImpl implements IActivityService {
	@Autowired
	private IActivityDao daoref;
	static List<Activity> b=new ArrayList<Activity>();
	List<Activity> activitylist= new ArrayList<Activity>();
	@Override
	public void addActivity(Activity activity) {
		daoref.save(activity);
		
	}
	@Override
	public List<Activity> getAllActivities()
	{
		
		
		//Activity c=new Activity();
		activitylist=daoref.findAll();
		System.out.println(activitylist);
				for (Activity activity : activitylist) {
					if(activity.getStatus().contentEquals("false") && (! b.contains(activity)) )     
					{
						b.add(activity);
					}
				}
				//System.out.println(b);
				return b;
	}
	@Override
	public void updateActivity(int id,Activity activity)
	{
	 Activity statustobechange=daoref.findById(id).get();
	 statustobechange.setStatus("true");
	 daoref.save(statustobechange);
	}
	/*@Override
	public List<Activity> getActivitiesByName(String name) {
		List<Activity> activitylist =new ArrayList<>();
		activitylist=daoref.findByActivity_name(name);
		List<Activity> statusTrueActivitylist =new ArrayList<>();
		for (Activity activity : activitylist) {
			if(activity.getStatus().contentEquals("true"))
			{
				
				statusTrueActivitylist.add(activity);
				}
		}
		
		return statusTrueActivitylist ;
	}*/
	
	@Override
	public List<Activity> getActivitiesByName(String name) {
		List<Activity> activityList= new ArrayList<Activity>();
		List<Activity> particularActivity=new ArrayList<Activity>();
		activityList=daoref.findAll();
		
		for(Activity activity:activityList)
		{
			if(activity.getActivity_name().contentEquals(name) && activity.getStatus().contentEquals("true") )
			{
				particularActivity.add(activity);
			}
		}
			return particularActivity;
	}
	@Override
	public List<Activity> showExistingActivity(String username) {
		System.out.println(username);
		List<Activity> activityList= new ArrayList<Activity>();
		List<Activity> particularActivity=new ArrayList<Activity>();
		activityList=daoref.findAll();
		for(Activity activity:activityList)
		{
			if((activity.getProvider().getUsername().equals(username))&& activity.getStatus().contentEquals("true") )
			{
				particularActivity.add(activity);
			}
		}
			return particularActivity;
	}
	
	
}
 