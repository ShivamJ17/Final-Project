package com.example.demo.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EndUser {
@Id
@GeneratedValue(strategy= GenerationType.IDENTITY)
private int userid;
private String username;
private String password;
private String name;
private String phone_no;
private String address;

public EndUser() {
	super();

}


public EndUser(int userid, String username, String password, String name, String phone_no, String address) {
	super();
	this.userid = userid;
	this.username = username;
	this.password = password;
	this.name = name;
	this.phone_no = phone_no;
	this.address = address;
}


public int getUserid() {
	return userid;
}

public void setUserid(int userid) {
	this.userid = userid;
}


public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPhone_no() {
	return phone_no;
}

public void setPhone_no(String phone_no) {
	this.phone_no = phone_no;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}


@Override
public String toString() {
	return "EndUser [userid=" + userid + ", username=" + username + ", password=" + password + ", name=" + name
			+ ", phone_no=" + phone_no + ", address=" + address + "]";
}


}
