package com.example.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IEndUserDao;
import com.example.demo.dto.EndUser;
import com.example.demo.repository.EndUserRepository;
@Service
public class EndUserServiceImpl implements IEndUserService {
	@Autowired
	private IEndUserDao daoref;
	@Autowired
	private EndUserRepository endUserRepository;
	private static final Logger logger = LoggerFactory.getLogger(EndUserServiceImpl.class);
	@Override
	public List<EndUser> getAllEndUsers() {
		return daoref.findAll();
	}

	
	 @Override public EndUser getEndUserById(int id) { Integer i=id; EndUser
	 e=daoref.findById(i).get(); System.out.println(e); return e; }
	 
	 @Override public void addEndUser(EndUser enduser)
	 { 
		 daoref.save(enduser); 
	 }
	 public void deleteEndUser(int id) { daoref.deleteById(id); }
	 
	@Override
	public EndUser Authenticate(EndUser user)
	{
		logger.info(user.getUsername()+ " " +user.getPassword());
		EndUser temp=new EndUser();
		temp.setUsername(user.getUsername());
		temp.setPassword(user.getPassword());
		List<EndUser> users = endUserRepository.findByUsername(user.getUsername());
		if(users.size()>0) {
			return users.get(0);
		}

		return null;
	}
}
