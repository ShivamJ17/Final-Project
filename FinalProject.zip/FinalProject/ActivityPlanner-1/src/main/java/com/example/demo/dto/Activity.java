
  package com.example.demo.dto;
  
  import javax.persistence.Entity; import javax.persistence.GeneratedValue;
  import javax.persistence.GenerationType; import javax.persistence.Id; import
  javax.persistence.ManyToOne;
  
  @Entity 
  public class Activity {
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private int activity_id;
  private String activity_name;
  private String activity_details;
  //particular provider related details of activity
  private String status="false";
  @ManyToOne 
  private Provider provider; 
  public Activity(int activity_id,String activity_name, String activity_details, String status,int provider_id) 
  { 
	  super(); 
	  this.activity_id = activity_id;
      this.activity_name = activity_name;
      this.activity_details = activity_details;
      this.status = status; 
      this.provider = new Provider(provider_id,"","","","","");
  
  }
  public Activity() 
  {
   }
public int getActivity_id() {
	return activity_id;
}
public void setActivity_id(int activity_id) {
	this.activity_id = activity_id;
}
public String getActivity_name() {
	return activity_name;
}
public void setActivity_name(String activity_name) {
	this.activity_name = activity_name;
}
public String getactivity_details() {
	return activity_details;
}
public void setactivity_details(String activity_details) {
	this.activity_details = activity_details;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Provider getProvider() {
	return provider;
}
public void setProvider(Provider provider) {
	this.provider = provider;
}
@Override
public String toString() {
	return "Activity [activity_id=" + activity_id + ", activity_name=" + activity_name + ", activity_details="
			+ activity_details + ", status=" + status + ", provider=" + provider + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + activity_id;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Activity other = (Activity) obj;
	if (activity_id != other.activity_id)
		return false;
	return true;
} 

  
  
  
  
  
  }
 