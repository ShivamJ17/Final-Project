package com.example.demo.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.example.demo.dto.Activity;

@Repository
public interface IActivityDao extends JpaRepository<Activity, Integer> {
	//@Query
 //public List<Activity> findByActivity_name(String name);
}
