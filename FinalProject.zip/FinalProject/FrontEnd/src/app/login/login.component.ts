import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user1:any;
constructor(private service:UserserviceService,private router:Router) { }

  ngOnInit() {
  }
  signIn(user:any){
    if(user.role == 1){
      this.service.SignInAdmin(user).then(response=>{
        
        console.log(response);
        //sessionStorage.setItem("loggedInUser",user.username);
        sessionStorage.setItem('loggedInUser',JSON.stringify(user));
        this.router.navigate(['/adminpage']).then(()=>{
          window.location.reload();
         console.log("you are inside admin page");
        });
      }).catch(error=>{
        console.log(error);
      });
    }
    if(user.role == 2){
      this.service.SignInUser(user).then(response=>{
        console.log(user);
        console.log(response);
        sessionStorage.setItem('loggedInUser',JSON.stringify(user));
        //sessionStorage.setItem("loggedInUser",user.username);
        this.router.navigate(['/home']).then(()=>{
          window.location.reload();
        });
      }).catch(error=>{
        console.log(error);
      });
    }
    if(user.role == 3){
      this.service.SignInClient(user).then(response=>{
        console.log(user);
       this. user1=response;
        console.log(this.user1.provider_id);
        sessionStorage.setItem('Id',this.user1.provider_id);
        sessionStorage.setItem('loggedInUser',JSON.stringify(user));
        //sessionStorage.setItem("loggedInUser",user.username);
        //sessionStorage.setItem("loggedInClient",user.provider.provider_id);
        this.router.navigate(['/clientpage']).then(()=>{
          window.location.reload();
        });
      }).catch(error=>{
        console.log(error);
      });
    }
   
    
    
  }

}
