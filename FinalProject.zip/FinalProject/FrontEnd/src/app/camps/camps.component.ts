import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-camps',
  templateUrl: './camps.component.html',
  styleUrls: ['./camps.component.css']
})
export class CampsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
