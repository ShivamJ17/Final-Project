import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientserviceService {

  constructor(private http:HttpClient) { }

  GetExistingActivity(username){
        var url="http://localhost:9091/activity/relatedactvities/"+username;
         return this.http.get(url);
     }
  AddActivity(activity){
    var id=sessionStorage.getItem("Id");
    var url="http://localhost:9091/activity/providers/"+id+"/activities";
         return this.http.post(url,activity);
  }
}
