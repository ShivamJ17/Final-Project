export class Activity {
    activity_id: number;
    activity_name: string;
    activity_details: string;
    //status:string;
    
    
}
