import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpeccampComponent } from './speccamp.component';

describe('SpeccampComponent', () => {
  let component: SpeccampComponent;
  let fixture: ComponentFixture<SpeccampComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpeccampComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpeccampComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
