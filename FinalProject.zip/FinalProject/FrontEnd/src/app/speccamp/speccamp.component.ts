import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-speccamp',
  templateUrl: './speccamp.component.html',
  styleUrls: ['./speccamp.component.css']
})
export class SpeccampComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
