import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatatransferService {
specclass:string;
activity:any;
  constructor() { }

datareceive(data:string){
this.specclass=data;
}

dataconsumer(){
  return this.specclass;
}
datafromspecact(activity){
sessionStorage.setItem('cartdata',JSON.stringify(activity));
}

}
