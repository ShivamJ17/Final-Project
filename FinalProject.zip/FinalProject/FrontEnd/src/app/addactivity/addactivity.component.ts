import { Component, OnInit } from '@angular/core';
import { ClientserviceService } from '../clientservice.service';

@Component({
  selector: 'app-addactivity',
  templateUrl: './addactivity.component.html',
  styleUrls: ['./addactivity.component.css']
})
export class AddactivityComponent implements OnInit {
  datasaved = false;
  message: string;
  user:any;
  constructor(private service:ClientserviceService) { }

  ngOnInit() {
  }
  
  addActivity(activity){

    // this.user=sessionStorage.getItem("loggedInUser");
    // console.log(this.user);
    this.service.AddActivity(activity).subscribe(data=>{
      data=activity;
      console.log(data);
      this.datasaved = true;
      this.message="You have added new activity successfully !!!"
    });

  }
}