import { Component, OnInit } from '@angular/core';
import { DatatransferService } from '../datatransfer.service';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-specclass',
  templateUrl: './specclass.component.html',
  styleUrls: ['./specclass.component.css']
})
export class SpecclassComponent implements OnInit {
childMessage:string;
consumer:string;
// srcimg:string;
activity:any=[];
  constructor(private dataservice:DatatransferService,private service:UserserviceService) { }

  ngOnInit() {
    this.consumer=this.dataservice.dataconsumer();
    console.log(this.consumer);
    this.service.ActivityDetails(this.consumer).subscribe(data=>{
      this.activity=data;
      console.log(this.activity);
    });

  }

}
