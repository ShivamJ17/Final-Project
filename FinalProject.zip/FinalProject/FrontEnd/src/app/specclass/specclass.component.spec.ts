import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecclassComponent } from './specclass.component';

describe('SpecclassComponent', () => {
  let component: SpecclassComponent;
  let fixture: ComponentFixture<SpecclassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecclassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecclassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
