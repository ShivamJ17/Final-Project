import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { DatatransferService } from '../datatransfer.service';

@Component({
  selector: 'app-class',
 templateUrl: './class.component.html',
 
  styleUrls: ['./class.component.css']
})
export class ClassComponent implements OnInit {
parentMessage;
  constructor(private router:Router,private dataservice:DatatransferService) { }

  ngOnInit() {
  }

  specificclass(activity:string){
    this.dataservice.datareceive(activity);
  }
  
}
