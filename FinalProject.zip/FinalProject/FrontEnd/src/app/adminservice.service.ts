import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})

export class AdminserviceService {
  constructor(private http:HttpClient) { }
  //private userUrl = 'http://192.168.2.11:9091/activity/verifyactivity';
  //private allowUrl = 'http://192.168.2.11:9091/activity/update/{id}';
  GetAllActivity():Observable<any[]>{
 //   return this.http.get("http://localhost:9091/activity/verifyactivity").toPromise();
      return this.http.get<any[]>("http://localhost:9091/activity/verifyactivity");
  }
  AllowActivity(acti,id:number){
    return this.http.put('http://localhost:9091/activity/update/'+id,acti);
  }
}
