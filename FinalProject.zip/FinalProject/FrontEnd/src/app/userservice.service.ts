import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private http:HttpClient) { }
  SignInUser(user){
    return this.http.post('http://localhost:9091/authenticate',user).toPromise();
  }
  SignInClient(user){
    return this.http.post('http://localhost:9091/authenticateprovider',user).toPromise();
  }
  SignInAdmin(user){
    return this.http.post('http://localhost:9091/authenticateadmin',user).toPromise();
  }
  SignUpUser(user){
    return this.http.post('http://localhost:9091/register',user).toPromise();
  }
  SignUpClient(user){
    return this.http.post('http://localhost:9091/registerprovider',user).toPromise();

  }

  ActivityDetails(activityName:string){
    var url="http://localhost:9091/activity/activities/"+activityName;
         return this.http.get(url);
    
  }
  CheckOut(activity,id:number){
   
    var url="http://localhost:9091/cart/addItem/"+id;
    return this.http.post(url,activity);
  }

}
