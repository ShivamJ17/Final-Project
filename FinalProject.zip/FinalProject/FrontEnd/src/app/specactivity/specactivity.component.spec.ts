import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecactivityComponent } from './specactivity.component';

describe('SpecactivityComponent', () => {
  let component: SpecactivityComponent;
  let fixture: ComponentFixture<SpecactivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecactivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecactivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
