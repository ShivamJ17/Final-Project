import { Component, OnInit } from '@angular/core';
import { DatatransferService } from '../datatransfer.service';
import { UserserviceService } from '../userservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-specactivity',
  templateUrl: './specactivity.component.html',
  styleUrls: ['./specactivity.component.css']
})
export class SpecactivityComponent implements OnInit {
  consumer:string;
  activity:any=[];
  user:any;
  constructor(private dataservice:DatatransferService,private service:UserserviceService,private router:Router) { }

  ngOnInit() {
    this.consumer=this.dataservice.dataconsumer();
    console.log(this.consumer);
    this.service.ActivityDetails(this.consumer).subscribe(data=>{
      this.activity=data;
      console.log(this.activity);
    });

  }
  addToCart(){
   this.user=JSON.parse(sessionStorage.getItem('loggedInUser'));
   if(!this.user){
     this.router.navigate(['/login']);
   }
   else{
    this.dataservice.datafromspecact(this.activity);
    this.router.navigate(['/cart']);
   }
    
  }

}
