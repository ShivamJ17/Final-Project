import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {FormsModule, FormBuilder, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { CartComponent } from './cart/cart.component';
import { FooterComponent } from './footer/footer.component';
import { ClassComponent } from './class/class.component';
import { CampsComponent } from './camps/camps.component';
import {MatRadioModule} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SpecclassComponent } from './specclass/specclass.component';
import { SpeccampComponent } from './speccamp/speccamp.component';
import { SpecactivityComponent } from './specactivity/specactivity.component';
import { HttpClientModule } from '@angular/common/http';

import { AdminpageComponent } from './adminpage/adminpage.component';
import { ClientpageComponent } from './clientpage/clientpage.component';
import { AddactivityComponent } from './addactivity/addactivity.component';

// routing

const appRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'class', component: ClassComponent },
  { path: 'camps', component: CampsComponent },
  { path: 'speccamps', component: SpeccampComponent },
  { path: 'specclass', component: SpecclassComponent },
  { path: 'specactivity', component: SpecactivityComponent },

  { path: 'cart', component: CartComponent },
  { path: 'adminpage', component:AdminpageComponent},
  {path: 'clientpage', component:ClientpageComponent},
  {path: 'addactivity', component:AddactivityComponent},

  { path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  
];

// routing

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    CartComponent,
    FooterComponent,
    ClassComponent,
    CampsComponent,
    SpecclassComponent,
    SpeccampComponent,
    SpecactivityComponent,
  
    AdminpageComponent,
    ClientpageComponent,
    AddactivityComponent,

  ],
  imports: [
    RouterModule.forRoot(
      appRoutes),
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    MatRadioModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
