import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from '../adminservice.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})



export class AdminpageComponent implements OnInit {
activity:any;


  constructor(private adminservice:AdminserviceService,private router:Router) { 
 
   }

  ngOnInit() {
    this.adminservice.GetAllActivity().subscribe(data=>this.activity=data);
    console.log(this.activity);
  }
  
  allowActivity(acti){

    this.adminservice.AllowActivity(acti,acti.activity_id).subscribe((data)=>{
      this.activity.splice(this.activity.indexOf(acti),1);
    },(error)=>{
      console.log(error);
    });
  }
  

}
