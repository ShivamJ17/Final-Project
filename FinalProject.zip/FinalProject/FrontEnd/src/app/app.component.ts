import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'activity-planner1';
  loggedInUser:string=null;
  loggedInClient:string=null;
  constructor(private router:Router) { }

  ngOnInit(){
    this.loggedInUser=JSON.parse(sessionStorage.getItem('loggedInUser'));
    this.loggedInClient=sessionStorage.getItem('loggedInClient');
  }
  onLogout(){
  
    console.log(sessionStorage.getItem("loggedInUser"));
    //localStorage.setItem("loggedInuser","");
    sessionStorage.removeItem("loggedInUser");
    console.log(sessionStorage.getItem("loggedInUser"));
    this.router.navigate(["/login"]).then(()=>{
      window.location.reload();
    })
    //window.location.reload();
    //this.router.navigate(['/login']);
  }
}
