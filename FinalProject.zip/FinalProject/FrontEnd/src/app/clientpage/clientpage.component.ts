import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClientserviceService } from '../clientservice.service';

@Component({
  selector: 'app-clientpage',
  templateUrl: './clientpage.component.html',
  styleUrls: ['./clientpage.component.css']
})
export class ClientpageComponent implements OnInit {
activity:any;
client_id:any;
user:any;
  constructor(private router:Router,private service:ClientserviceService) { }

  ngOnInit() {
    this.user=sessionStorage.getItem("loggedInUser");
    console.log(this.user);
    this.client_id=sessionStorage.getItem("loggedInClient");
    console.log(this.client_id);
    this.service.GetExistingActivity(this.user).subscribe(data=>
      
      {
     
        this.activity = data;
        console.log(data);
    
      });
      
  }

  addActivity(){
    this.router.navigate(['/addactivity']);
  }

}
