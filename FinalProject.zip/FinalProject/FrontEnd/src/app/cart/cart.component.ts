import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
activity:any;
msg='';
user:any;
id:number;
  constructor(private service:UserserviceService) { }

  ngOnInit() {
   this.activity=JSON.parse(sessionStorage.getItem('cartdata'));
   console.log(this.activity);
   this.user=sessionStorage.getItem("loggedInUser");
    this.id=this.user.userid;
    console.log(this.id);

  }
  checkout(){
    console.log(this.id);
    this.service.CheckOut(this.activity,this.id).subscribe(data=>{
      this.activity=data;
      this.msg="Congrats!!!!! You have subscribed our service...."
    });

    
  }

}
