import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { FormGroup, FormBuilder,NgForm, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  datasaved = false;
  message: string;
  constructor(private service:UserserviceService) {
  
   }

  ngOnInit() {
   
  }

  
    
  
  signUp(user){
    if(user.role == 1){
      this.service.SignUpUser(user).then(response=>{
        console.log(response);
        this.datasaved = true;
       
        this.message="You have registered successfully as User!!!"
     
        
      }).catch(error=>{
        console.log(error);
        
      });
    }
    console.log(user);
    if(user.role == 2){
      this.service.SignUpClient(user).then(response=>{
        console.log(user);
        console.log(response);
        this.datasaved = true;
       
        this.message="You have registered successfully as Client!!!"
     
        
      }).catch(error=>{
        console.log(error);
        
      });
    }
   
  }
  newForm()
  {
    
  }


}
